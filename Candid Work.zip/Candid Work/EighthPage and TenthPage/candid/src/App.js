
import React from 'react';
import './App.css';

function App() {
    return (
<div className="body">
<div className="hand-img">
<div className="div8"></div>  
<div className="div2">1:00 PM | Sun, Jun 6</div>
<div className="three-dots"></div>
<div className="div3">Play Area</div>
<div className="x"></div>
<div className="div4"><div className="mic"></div><div className="video"></div></div>
<div className="y">
<div className="karaoke1"></div>
<div className="karaoke2"></div>
</div>
<div className="z">
<div className="a">Karaoke</div>
<div className="b">Karaoke</div>
</div>
<div className="chat"></div>
</div>
</div>
);
}

export default App;
