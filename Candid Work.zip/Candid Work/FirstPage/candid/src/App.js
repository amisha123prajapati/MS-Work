import './App.css';
import Greet from "./ComponentA/Greet";
import './ComponentA/App.css';

function App(){
  return(
    <div className="App">
      <Greet/>
    </div>
  );
}

export default App;