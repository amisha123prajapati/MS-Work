import React from 'react';

function Greet(){
    return (<div>
    <div className="body">
    <div className="candid-logo"></div>   
    <div className="top-heading">Candid Date</div>
     <div className="top-right-part">1:00PM | Sun,Jun 6</div>
    <div className="reactangle">
    <div className="you">You</div>
    <div className="small-rectangle">
     <div className="mic"></div> 
     <div className="video"></div> 
     <div className="setting"></div>
     </div>
     <div className="right-part">
    <div className="div1">123-abc-xyz</div> 
    <div className="div2">Ready to join?</div> 
    <div className="image"></div> 
    <div className="div3">Kelly is here</div> 
    <button className="join-button">Join</button> 
    </div> 
     </div>   
    </div>
    </div>
    );
}


export default Greet;