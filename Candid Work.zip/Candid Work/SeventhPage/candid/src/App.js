
import React from 'react';
import './App.css';

function App() {
    return (
<div className="body">
<div className="div1">Candid Date</div>
<div className="div2">1:00 PM | Sun, Jun 6</div>
<div className="div3">123 - abc - xyz</div>
<div className="div4"><div className="mic"></div><div className="video"></div></div>
<button className="div5">Join</button>
<div className="div6"></div>
<div className="div7">Kelly is here</div>
<div className="div8"></div>
</div>
);
}

export default App;
