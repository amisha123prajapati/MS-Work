import React from 'react';
import './App.css';

function App() {
  return (
    <div className="body">
     <div className="square-img">
       <div className="link-page">
         </div>
       </div>
     <div className="right-part">
     <div className="rect1"></div>
     <div className="rect2"></div>
     <div className="try-other-game">Try other game?</div>
     <div className="bottom-rect">
       <div id="time">7 June 2021 | 4:30</div>
      <div className="mic"></div>
      <div className="video"></div>
      <div className="thumb"></div>
      <div className="red-button"></div>
      <div className="chat"></div>
      <div className="three-dot"></div>
       </div> 
    </div>
    </div>
    );
}

export default App;
